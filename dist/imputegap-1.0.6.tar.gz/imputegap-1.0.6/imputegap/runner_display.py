from imputegap import __version__

def display_title():
    print(f"ImputeGAP, A library of Imputation Techniques for Time Series Data {__version__}\n\n")