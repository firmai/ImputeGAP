from imputegap import __version__

def display_title():
    print(f"\nImputeGAP {__version__}\n\n")