def display_title():
    print("ImputeGAP, A library of Imputation Techniques for Time Series Data, V0.1.0\n")