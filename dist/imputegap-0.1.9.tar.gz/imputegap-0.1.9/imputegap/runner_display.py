from imputegap import __version__

def display_title():
    print("ImputeGAP, A library of Imputation Techniques for Time Series Data", __version__, "\n")