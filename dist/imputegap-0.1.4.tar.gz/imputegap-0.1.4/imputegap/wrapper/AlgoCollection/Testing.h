//
// Created by Zakhar on 07.03.2017.
//

#pragma once

namespace Testing
{

//
// Test scenarios
//
void TestCorr();

void TestCD_RMV();

void TestIncCD();

void TestCD();

void TestBasicOps();

void TestBasicActions();

} //namespace Testing
